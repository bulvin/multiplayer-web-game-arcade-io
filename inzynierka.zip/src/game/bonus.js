export class Bonus {
    constructor(x, y, name,duration){
        this.position = {
            x : x,
            y : y,
        }
        this.name = name;
        this.duration = duration;
    }
}