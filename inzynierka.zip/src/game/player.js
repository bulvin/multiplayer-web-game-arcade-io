export class Player {
  constructor(user, game) {
    this.user = user;
    this.game = game;
    this.psize = 32;
    this.x = 0;
    this.y = 0;
    this.speed = 0.25;
    this.color = `hsl(${360 * Math.random()}, 100%, 50%, 1)`;
    this.tileColor = "rgba(255, 0, 0, 0.8)";
    this.lands = [];
    this.tail = [];
    this.input = [];
    this.score = 0;
    this.dead = false;
    this.direction = -1;
    this.multiplyScore = 1;
    this.deadTimer = 0;
    this.deadInterval = 5000;
    this.kills = 0;
    this.deaths = 0;
    this.abilitiesBinds = {};
    this.activeAbility = null;
    this.activeBonus = null;
    this.slowMultiplier = 1;
    this.mid = { x: 0, y: 0 };
    this.beforeTail = { x: this.x, y: this.y }


  }

  update(deltaTime) {

    if (this.dead) {
      if (this.deadTimer > this.deadInterval) {
        this.dead = false;
        this.direction = -1;
        this.deadTimer = 0;
        this.input = [];
        this.initBase();
      } else {
        this.deadTimer += deltaTime;
      }
    } else {

      this.checkTakeEffects();
      if (this.activeAbility) {
        this.activeAbility.duration -= deltaTime;

        if (this.activeAbility.duration <= 0) {
          this.resetAbilityEffects();
        }
      }
      if (this.activeBonus) {
        this.activeBonus.duration -= deltaTime;

        if (this.activeBonus.duration <= 0) {
          this.resetBonusEffect();
        }
      }

      const oldLand = this.game.map.getTile(Math.floor(this.y), Math.floor(this.x));
      if (this.input.length > 0) {
        if (Number.isInteger(this.x) && Number.isInteger(this.y)) {
          this.setDirection();
        }

      }

      this.move();

      if (this.isHitInBorders() || this.isHitSelf()) {
        this.dead = true;
        this.deaths++;
        this.clear();
        return;
      }

      const land = this.game.map.getTile(Math.floor(this.y), Math.floor(this.x));
      const distance = this.calculateDistance(this.x, this.y, oldLand.x, oldLand.y);

      if (oldLand !== land) {
        if (oldLand.playerId !== this.user.id && !this.dead) {
          this.addLandToTail(oldLand);
        }
        if (this.tail.length < 0) {
          this.beforeTail.x = Math.floor(this.x);
          this.beforeTail.y = Math.floor(this.y);
        }
        if (distance < this.speed) {
          const steps = Math.floor(distance / this.speed);

          for (let i = 1; i < steps; i++) {
            const intermediateX = Math.floor(oldLand.x + (this.x - oldLand.x) * (i / steps));
            const intermediateY = Math.floor(oldLand.y + (this.y - oldLand.y) * (i / steps));

            const intermediateLand = this.game.map.getTile(intermediateY, intermediateX);

            if (intermediateLand.playerId !== this.user.id && !this.dead) {
              this.addLandToTail(intermediateLand);
            }
          }

        }

        if (land && this.user.id === land.playerId && this.tail.length > 0) {
          this.tail.push(land);

          this.takeArea();

          this.gainPoints();
          this.tail = [];
        }
      }

      const ability = this.useAbility();
      if (ability) {
        this.activeAbility = ability;
      }

    }
  }
  move() {

    const moveAmount = this.speed * this.slowMultiplier;
    if (this.direction === Direction.Up) {
      this.y -= moveAmount;
    } else if (this.direction === Direction.Down) {
      this.y += moveAmount;
    } else if (this.direction === Direction.Right) {
      this.x += moveAmount;
    } else if (this.direction === Direction.Left) {
      this.x -= moveAmount;
    }
  }

  setDirection() {
    if (this.input.includes(Keys.A)) {
      if (this.direction === Direction.Right) this.direction = Direction.Right;
      else this.direction = Direction.Left;
    } else if (this.input.includes(Keys.D)) {
      if (this.direction === Direction.Left) this.direction = Direction.Left;
      else this.direction = Direction.Right;
    } else if (this.input.includes(Keys.W)) {
      if (this.direction === Direction.Down) this.direction = Direction.Down;
      else this.direction = Direction.Up;
    } else if (this.input.includes(Keys.S)) {
      if (this.direction === Direction.Up) this.direction = Direction.Up;
      else this.direction = Direction.Down;
    }
  }
  addLandToTail(land) {
    land.hasTail = true;
    land.color = this.tileColor;
    land.playerId = this.user.id;
    return this.tail.push(land);
  }

  takeArea() {

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

    const start = this.tail[0];
    const end = this.tail.pop();

    // const startTile = this.game.map.getTile(this.beforeTail.y, this.beforeTail.x);
    // this.tail.push(startTile);


    const helps = [...this.tail, ...this.lands];


    for (const segment of helps) {
      if (segment.x < minX) minX = segment.x;
      if (segment.x > maxX) maxX = segment.x;
      if (segment.y < minY) minY = segment.y;
      if (segment.y > maxY) maxY = segment.y;
    }


    const bounds = { minX, minY, maxX, maxY };
    
    const boxTiles = [];
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        let tile = this.game.map.getTile(y, x);
        if (tile.playerId === this.user.id && !tile.hasTail) {
          boxTiles.push({ x, y });

        }

      }
    }

    this.tail = this.tail.concat(this.getTailComplement(start.x, start.y, end.x, end.y, boxTiles));


    this.floodFill(bounds);
    this.updateTailAndLands();
  }
  floodFill(boxBoundary) {
    const minX2 = Math.min(...this.tail.map(segment => segment.x));
    const maxX2 = Math.max(...this.tail.map(segment => segment.x));
    const minY2 = Math.min(...this.tail.map(segment => segment.y));
    const maxY2 = Math.max(...this.tail.map(segment => segment.y));

    const midX = Math.floor((minX2 + maxX2) / 2);
    const midY = Math.floor((minY2 + maxY2) / 2);

    const bounds = {minX2, minY2, maxX2, maxY2};
    const visited = Array.from({ length: this.game.map.rows }, () =>
      new Array(this.game.map.cols).fill(false));

    let helpTail = [];
    helpTail = helpTail.concat(this.tail);


    console.log(minY2);
    console.log(boxBoundary.minY);
    for (let y = 0; y <= boxBoundary.maxY; y++) {
      for (let x = 0; x <= boxBoundary.maxX; x++) {
        if (!this.isInBoundingBox(x, y, boxBoundary)) continue;

        const queue = [{ x: x, y: y }];
        console.log(queue);
        while (queue.length > 0) {
          
          const { x, y } = queue.shift();

          if (!this.isInBoundingBox(x, y, bounds) || visited[y][x] || this.isEdge(x, y, helpTail)) {
            continue;
          }

          visited[y][x] = true;
          const tile = this.game.map.getTile(y, x);
          tile.playerId = this.user.id;
          tile.color = this.color;
          tile.hasTail = false;
          this.tail.push(tile);

          queue.push({ x: x + 1, y: y });
          queue.push({ x: x - 1, y: y });
          queue.push({ x: x, y: y + 1 });
          queue.push({ x: x, y: y - 1 });

        }
      }

    }

  }
  getTailComplement(startX, startY, endX, endY, tiles) {
    const points = this.findShortestPath(startX, startY, endX, endY, tiles);

    const complementTiles = [];

    points.forEach((point) => {
      const tile = this.game.map.getTile(point.y, point.x);
      complementTiles.push(tile);
    });

    return complementTiles;
  }
  findShortestPath(startX, startY, endX, endY, tiles) {
    const queue = [{ x: startX, y: startY, distance: 0, path: [] }];
    const visited = new Set();

    while (queue.length > 0) {

      const { x, y, distance, path } = queue.shift();


      if (x === endX && y === endY) {
        return path;
      }

      if (visited.has(`${x},${y}`)) {
        continue;
      }

      visited.add(`${x},${y}`);

      const neighbors = [
        { x: x + 1, y, direction: "Right" },
        { x: x - 1, y, direction: "Left" },
        { x, y: y + 1, direction: "Down" },
        { x, y: y - 1, direction: "Up" },
      ];

      for (const neighbor of neighbors) {
        if (tiles.some(tile => tile.x === neighbor.x && tile.y === neighbor.y)) {
          queue.push({
            x: neighbor.x,
            y: neighbor.y,
            distance: distance + 1,
            path: [...path, { x: neighbor.x, y: neighbor.y }],
          });
        }
      }
    }

    return null; // No path found
  }
  isInBoundingBox(x, y, bounds) {
    return x >= bounds.minX && x <= bounds.maxX && y >= bounds.minY && y <= bounds.maxY;
  }
  isEdge(x, y, boundaryPoints) {

    for (const point of boundaryPoints) {
      if (point.x === x && point.y === y) {
        return true;
      }
    }
    return false;
  }

  updateTailAndLands() {
    this.tail.forEach(segment => {
      segment.playerId = this.user.id;
      segment.color = this.color;
      segment.hasTail = false;
    });
    this.lands.push(...this.tail);
    this.tail = [];

  }
  isTail(neighborX, neighborY) {
    return this.tail.some(segment => segment.x === neighborX && segment.y === neighborY);

  }

  gainPoints() {
    let totalScore = 0;
    this.lands.forEach((land) => {
      totalScore += land.score * this.multiplyScore;
    });
    this.score += totalScore;
  }

  getOwnPercentageOfMap() {
    const squaresAll = this.game.map.countTiles();
    const percent = (this.lands.length / squaresAll) * 100;

    return percent.toFixed(1);
  }
  isHitSelf() {
    if (this.activeAbility && this.activeAbility.name === "noHitSelf") {
      return false;
    } else {
      for (const segment of this.tail) {
        if (segment.x === this.x && segment.y === this.y) {
          return true;
        }
      }
    }

    return false;
  }
  isHitInBorders() {
    return (
      this.x < 0 ||
      this.x >= this.game.map.cols ||
      this.y < 0 ||
      this.y >= this.game.map.rows
    );
  }
  isSomeoneHitsMe(otherPlayer) {
    for (const segment of this.tail) {
      if (segment.x === otherPlayer.x && segment.y === otherPlayer.y) {
        this.dead = true;
        this.deaths++;
        this.clear();
        otherPlayer.kills++;
        otherPlayer.score += 10;
        break;
      }
    }
  }
  clear() {

    this.lands.forEach((square) => {
      square.playerId = 0;
      square.hasTail = false;
      square.color = "#111";
    });
    this.direction = -1;


    this.tail.forEach((square) => {
      square.hasTail = false;
      square.color = "#111";
    });

    this.lands = [];
    this.tail = [];
    this.score = 0;
    this.direction = -1;
    this.speed = 0.25;
  }
  spawn() {
    const spawnBorder = Math.floor(Math.random() * 4);
    let spawnRow, spawnCol;

    const borderBuffer = 1;

    if (spawnBorder === 0) {
      spawnRow = borderBuffer;
      spawnCol =
        Math.floor(Math.random() * (this.game.map.cols - 12 + borderBuffer)) +
        6;
    } else if (spawnBorder === 1) {
      spawnRow =
        Math.floor(Math.random() * (this.game.map.rows - 12 + borderBuffer)) +
        6;
      spawnCol = this.game.map.cols - 1 - borderBuffer;
    } else if (spawnBorder === 2) {
      spawnRow = this.game.map.rows - 1 - borderBuffer;
      spawnCol =
        Math.floor(Math.random() * (this.game.map.cols - 12 + borderBuffer)) +
        6;
    } else {
      spawnRow =
        Math.floor(Math.random() * (this.game.map.rows - 12 + borderBuffer)) +
        6;
      spawnCol = borderBuffer;
    }

    const spawnTile = this.game.map.getTile(spawnRow, spawnCol);
    this.x = spawnTile.x;
    this.y = spawnTile.y;
    this.mid.x = spawnTile.x;
    this.mid.y = spawnTile.y;

  }
  checkTakeEffects() {
    const abilities = this.game.abilities;
    const bonuses = this.game.bonuses;

    abilities.forEach((ability, index) => {
      const abilityPosition = ability.position;

      const distance = Math.hypot(
        abilityPosition.x - this.x,
        abilityPosition.y - this.y
      );
      const abilityRadius = Math.PI * 2;

      const collisionThreshold = this.psize + 2 + abilityRadius;
      if (distance <= collisionThreshold) {
        this.applyAbilityEffect(ability);
        abilities.splice(index, 1);
      }
    });

    bonuses.forEach((bonus, index) => {
      const bonusPosition = bonus.position;

      const distance = Math.hypot(
        bonusPosition.x - this.x,
        bonusPosition.y - this.y
      );
      const bonusRadius = Math.PI * 2;

      const collisionThreshold = this.psize + 2 + bonusRadius;
      if (distance <= collisionThreshold) {
        this.applyBonusEffect(bonus);
        bonuses.splice(index, 1);
      }
    });
  }
  applyAbilityEffect(ability) {
    if (!this.abilitiesBinds[Keys.R]) {
      this.abilitiesBinds[Keys.R] = ability;
    } else if (!this.abilitiesBinds[Keys.T]) {
      this.abilitiesBinds[Keys.T] = ability;
    } else if (!this.abilitiesBinds[Keys.E]) {
      this.abilitiesBinds[Keys.E] = ability;
    }
  }
  useAbility() {
    if (!this.activeAbility) {
      let abilityKey = null;
      if (this.input.includes(Keys.R)) {
        abilityKey = Keys.R;
      } else if (this.input.includes(Keys.T)) {
        abilityKey = Keys.T;
      } else if (this.input.includes(Keys.E)) {
        abilityKey = Keys.E;
      }

      if (abilityKey && this.abilitiesBinds[abilityKey]) {
        const ability = this.abilitiesBinds[abilityKey];
        if (ability.name === "Prędkość" && this.activeAbility !== "Prędkość") {
          this.speed *= 2;
        } else if (
          ability.name === "Spowolnienie" &&
          this.activeAbility !== "Spowolnienie"
        ) {
          for (const id in this.game.players) {
            if (id !== this.user.id) {
              const otherPlayer = this.game.players[id];
              otherPlayer.slowMultiplier = 0.5;
            }
          }
        } else if (
          ability.name === "Powrót" &&
          this.activeAbility !== "Powrót"
        ) {
          if (this.lands.length > 0) {
            const randomIndex = Math.floor(Math.random() * this.lands.length);
            const randomLand = this.lands[randomIndex];

            this.x = randomLand.x;
            this.y = randomLand.y;
            this.tail.forEach((tail) => (tail.color = "#111"));
            this.tail = [];
          }
        }

        return ability;
      }
    }
    return null;
  }

  resetAbilityEffects() {
    if (this.activeAbility.name === "Prędkość") {
      this.speed *= 0.5;
    } else if (this.activeAbility.name === "Spowolnienie") {
      for (const id in this.game.players) {
        if (id !== this.user.id) {
          const otherPlayer = this.game.players[id];
          otherPlayer.slowMultiplier = 1;
        }
      }
    }

    for (const key of Object.keys(this.abilitiesBinds)) {
      if (this.abilitiesBinds[key] === this.activeAbility) {
        this.abilitiesBinds[key] = null;
        break;
      }
    }

    this.activeAbility = null;
  }
  applyBonusEffect(bonus) {
    if (bonus.name === "x2") {
      this.multiplyScore = 2;
    } else if (bonus.name === "x4") {
      this.multiplyScore = 4;
    } else if (bonus.name === "x8") {
      this.multiplyScore = 8;
    }
    this.activeBonus = bonus;
  }
  resetBonusEffect() {
    if (
      this.activeBonus.name === "x2" ||
      this.activeBonus.name === "x4" ||
      this.activeBonus.name === "x8"
    ) {
      this.multiplyScore = 1;
    }
    this.activeBonus = null;
  }
  initBase() {

    this.spawn();

    for (let row = -1; row < 2; row++) {
      for (let col = -1; col < 2; col++) {
        const newRow = this.y + row;
        const newCol = this.x + col;

        if (
          newRow >= 0 &&
          newRow < this.game.map.rows &&
          newCol >= 0 &&
          newCol < this.game.map.cols
        ) {
          const spawnLand = this.game.map.getTile(newRow, newCol);
          spawnLand.playerId = this.user.id;
          spawnLand.color = this.color;
          this.lands.push(spawnLand);
        }
      }
    }
  }
  setInput(input) {
    const inputKeys = ["w", "s", "a", "d", "e", "r", "t"];
    const validatedInput = input.filter((key) => inputKeys.includes(key));

    if (validatedInput.length > 0) {
      this.input = input;
    }
  }
  calculateDistance(x1, y1, x2, y2) {
    return Math.hypot(x2 - x1, y2 - y1);
  }

  getCountTiles() {
    return this.lands.length;
  }

  toJSON() {
    const territory = this.getOwnPercentageOfMap();
    return {
      nickname: this.user.name,
      color: this.color,
      x: this.x,
      y: this.y,
      psize: this.psize,
      score: this.score,
      dead: this.dead,
      kills: this.kills,
      deaths: this.deaths,
      territory: territory,
      abilities: this.abilitiesBinds,
      bonus: this.activeBonus,
      activeAbility: this.activeAbility,
      slowMultiplier: this.slowMultiplier,
      tileColor: this.tileColor,
    };
  }


}

const Keys = {
  W: "w",
  S: "s",
  A: "a",
  D: "d",
  R: "r",
  T: "t",
  E: "e",
};

const Direction = {
  Up: 0,
  Down: 1,
  Right: 2,
  Left: 3,
};
