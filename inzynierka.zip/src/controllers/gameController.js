export class GameController {
    constructor(game, roomController) {
        this.game = game;
        this.roomController = roomController;

    }

    
}