export class PlayerController {
    constructor(userController, player) {
        this.userController = userController;
        this.player = player;
        this.gameLoopInterval = null;
    }
    handleInput(input) {
        this.player.setInput(input);
    }
    sendGameState() {
        let lastTimestamp = performance.now();

        if (this.gameLoopInterval) {
            clearInterval(this.gameLoopInterval);
        }

        this.gameLoopInterval = setInterval(() => {
            if (this.player.game.gameOver) {
                clearInterval(this.gameLoopInterval);
                return;
            }
      
            const currentTime = performance.now();
            const deltaTime = currentTime - lastTimestamp;
      
            this.player.game.update(deltaTime, currentTime);
            this.userController.socket.emit('updateGame', this.player.game.toJSON(), currentTime);
            lastTimestamp = currentTime;
        }, 1000 / 60); 
    }
    stopSendingGameState() {
        if (this.gameLoopInterval) {
            clearInterval(this.gameLoopInterval);
        }
    }
  
}